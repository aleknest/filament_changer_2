                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2470843
Classic Poker Chip (dual color) by DrLex is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This is a basic poker chip for dual extrusion printing, in classic 39 mm diameter size (3.3 mm thick). If you want it to have the same size as the usual cheap Chinese stuff, scale up to 102.56% for 40 mm diameter.

I mainly created this to have a more interesting and stylish test piece for testing and calibrating my dual extrusion setup. Now every not entirely failed test print contributes to my stash!
This print is particularly good at revealing misalignment of multi-extruder setups. Check for gaps between the main body and inlays, and check that the six outer notches are flush with the edge of the chip.

# Print Settings

Printer Brand: FlashForge
Printer: Creator Pro
Rafts: No
Supports: No
Resolution: 0.2 mm
Infill: 60%

Notes: 
Print with 100% infill and a heavy filament to give them some weight!